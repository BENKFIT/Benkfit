package spring.mvc.benkfit.service;

public interface Service_syk {

}
