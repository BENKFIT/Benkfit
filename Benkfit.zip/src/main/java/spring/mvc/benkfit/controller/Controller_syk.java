package spring.mvc.benkfit.controller;

import org.slf4j.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Controller_syk {
	
	private static final Logger logger = LoggerFactory.getLogger(Controller_syk.class);
	
	/*
	 * @RequestMapping("index_syk")
	 * public String index_syk(){
	 * 		return "Template/index"; 
	 * }
	 */
	
	
}
